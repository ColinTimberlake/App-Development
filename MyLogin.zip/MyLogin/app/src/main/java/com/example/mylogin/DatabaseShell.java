package com.example.mylogin;

import java.util.HashMap;
import java.util.Scanner;

public class DatabaseShell {

    // Main driver method

    // Create an empty hash map by declaring object
    // of string and integer type
    HashMap<String, String> map = new HashMap<String, String>();
    Scanner scrn= new Scanner(System.in);

    public void addItem() {
        System.out.println("What is the item number?");
        String itemNumber=scrn.nextLine();
        System.out.println("What is the item name?");
        String itemName= scrn.nextLine();
        map.put(itemNumber, itemName);
    }
    public void removeItem() {
        System.out.println("What is the name of the item you wish to remove?");
        String item= scrn.nextLine();
        map.get(item);
        map.remove(item);
    }
    public void changeItem() {
        int quantity=1;
        System.out.println("What would you like the new quantity to be?");
        int quantity2= scrn.nextInt();
    }
    public void displayTable() {
        System.out.println(map);
    }
}
