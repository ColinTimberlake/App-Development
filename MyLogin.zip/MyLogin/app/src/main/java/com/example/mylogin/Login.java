package com.example.mylogin;

import java.util.HashMap;
import java.util.Scanner;
import java.io.*;

public class Login {

    HashMap<String, String> map = new HashMap<>();
    Scanner scrn = new Scanner(System.in);
    public void loginAttempt() {

        System.out.println("Enter Username:");
        String userName = scrn.nextLine();
        System.out.println("Enter Password:");
        String passWord = scrn.nextLine();
        if (map.containsValue(userName)) {
            String password2 = map.get(userName);
            if (passWord == password2) {
                System.out.println("Logging on");
            }
        } else {
            System.out.println("Login Failed. Please try Again");
        }
    }
    public void buttonClicked() {
        System.out.println("What is your new username");
        String username = scrn.nextLine();
        System.out.println("what is your password");
        String password = scrn.nextLine();
        map.put(username, password);
    }
}
