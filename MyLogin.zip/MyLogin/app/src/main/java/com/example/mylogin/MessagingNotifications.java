package com.example.mylogin;

import android.Manifest;
import android.app.Notification;
import java.util.Scanner;
import java.io.*;

public class MessagingNotifications {
    public static void main()
    {
        Scanner scrn = new Scanner(System.in);
        System.out.println("Would you Like to receive SMS notifications? yes or no?");
        String answer = scrn.nextLine();

        if (answer == "yes") {
            String sendMessage="yes";
            System.out.println("Thank you. We Will Send SMS Messages");
        }
        else {
            System.out.println("Thank you. We Won't Be Sending SMS Messages");
        }
        // At last, if the user has denied notifications, and you
        // want to be respectful there is no need to bother them anymore.

    }
}
